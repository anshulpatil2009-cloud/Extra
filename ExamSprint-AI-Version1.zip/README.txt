ExamSprint AI Version 1 — GitHub Pages

WHAT'S NEW
- AI Hub with study-management recommendations based on your saved tracker data.
- Local rule-based Study Manager chat for planning, revision, tests, backlogs and focus.
- Progress summary cards for today's tasks, overdue tasks, open mistakes and tests logged.
- No paid API and no API key. This is NOT a generative AI model and cannot reliably solve open-ended academic questions.
- Study data remains in the browser's local storage on that device. Use Export backup in Home before switching browsers/devices.

DEPLOY TO YOUR EXISTING GITHUB PAGES SITE
1. Download and extract this ZIP on your computer.
2. Open your repo: https://github.com/anshulpatil2009-cloud/-Examsprint-/
3. Upload/replace these SIX root files: index.html, manifest.webmanifest, sw.js, icon-192.png, icon-512.png. (README.txt is optional.)
4. Commit the changes to the main branch. GitHub Pages should redeploy automatically.
5. Open https://anshulpatil2009-cloud.github.io/-Examsprint-/ and refresh. If an old version remains, close the tab and reopen it; service-worker caches may take a moment to update.

IMPORTANT
- Keep these files at the repository root; the manifest and service worker paths are set for root icons.
- Do not publish API keys or passwords in this repository.
- GitHub Pages is static hosting. A real generative AI tutor needs a secure backend and an AI provider; this version does not pretend otherwise.
